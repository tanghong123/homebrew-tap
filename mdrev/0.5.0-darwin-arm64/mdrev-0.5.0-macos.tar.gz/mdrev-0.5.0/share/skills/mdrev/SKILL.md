---
name: mdrev
description: Act on review notes left on Markdown documents, polish a draft assembled from gathered research, and show a human what an edit changed in prose. Use when asked to "address the comments/notes on this doc", "resolve the review notes", "polish this draft", "clean up the material I gathered", when a repository contains a `.mdrev/` directory, or when a Markdown file needs its changes reviewed rather than its diff read.
---

# mdrev

`mdrev` is code review for prose: it renders a Markdown file as a redline between two
git revisions, carries review notes anchored to the text, and hands the results to you
through the command line. Two jobs bring you here — **acting on notes**, and **polishing
a draft someone assembled from research**. Both are below.

Everything here works headless. `--notes` and `--resolve` read and write the JSONL
sidecars directly, so no viewer, browser, or daemon has to be running — which is exactly
the situation you are in while editing.

## Acting on review notes

```bash
mdrev --notes                  # every open note in the repo
mdrev --notes doc.md           # just this document
mdrev --notes --json           # the same, machine-readable — prefer this
mdrev --notes --last 3         # only notes filed against the last 3 revisions
mdrev --notes --all            # include already-closed notes
```

The loop is: read the notes, make the edits, **close each note as you finish it** — not
in a batch at the end. A half-done run that closed what it finished is recoverable; one
that closed nothing is indistinguishable from one that did nothing.

```bash
mdrev --resolve <id> --note "what you changed"     # done
mdrev --wontfix <id> --note "why not"              # deliberately not doing it
```

The id alone is enough — you never need to name the file it lives in.

### Read the anchor state before you act

Each note reports how the text it points at has fared since it was written. **This is
the most useful field in the output** and it changes what you should do:

| State | What happened | What to do |
|---|---|---|
| `exact` | The text is unchanged | The note is live. Do the work. |
| `moved` | Text is intact but sits elsewhere | Same — a reorder or an edit above it. |
| `changed` | The text was reworded | **Check before editing.** Compare `currentText` against `anchor.exact`; someone may have already addressed it. |
| `orphaned` | Nothing resembling it survives | Usually already done or moot. Read it, then close it with `--wontfix` or `--resolve` explaining why — do not re-add deleted text to satisfy a stale note. |

`changed` and `orphaned` are the ones that waste effort if ignored: acting on them
blindly means redoing work, or reinstating something a human deliberately removed.

### The note's own fields

`--json` gives you `{path, annotation, state, currentText}`. Inside `annotation`:

- `body` — what the reviewer asked for. This is the instruction.
- `anchor.exact` — the text they selected, **as rendered**, not as written in Markdown.
  A quote reads `three times` where the source says `**three times**`. Search the
  rendered sense of the document, not the raw characters, or you will not find it.
- `anchor.trail` — the heading path down to it, the fastest way to locate the spot.
- `rev` — the commit the note was filed on. `blob` — a content snapshot of the document
  as the reviewer saw it, readable with `git cat-file blob <sha>` when you need to know
  exactly what they were looking at.
- `status` — only `open` notes need action; the listing filters to those unless `--all`.

## Polishing a draft assembled from research

A document built by gathering carries a convention you must honour. It has three kinds
of content, and confusing them is the main way this task goes wrong:

```markdown
## Rollout risks                    ← headings: the author's structure. Keep.

Capacity was the binding constraint.  ← plain text: the author's voice. Preserve intent.

> Regional rollout hit capacity limits in three of five zones.
> — [ops-review.md § Capacity](ops-review.md#capacity)
```

**Blockquotes ending in an `— [source](link)` line are raw gathered material.** They are
not the author's words. Use them, rewrite them, merge them into prose, cite them or drop
them — that is the job. Everything *outside* a blockquote is the author's framing:
preserve what it means.

Two rules that matter more than they look:

- **Never silently drop a gathered fragment.** If material does not belong, say so in
  your reply rather than deleting it quietly — the author chose each fragment by hand,
  and a vanished blockquote is the failure this workflow leaks through.
- **Decide what happens to attributions and say which you did**: convert them to
  footnotes, or remove them, depending on whether the finished document needs citations.

Annotations on such a draft carry the author's intent for each section. Read them
alongside the text — they say what a part is *for*, which the prose often does not.

## Showing a human what changed

When a person should look at a change rather than read a diff:

```bash
mdrev doc.md --last 3          # the file's last three changes, as a redline
mdrev doc.md --since "2 days ago"
mdrev doc.md                   # just render it
```

This opens a viewer in their browser. Only do it when asked, or when prose changes are
substantial enough that reading them as a unified diff would be worse.

## Two things that will trip you up

**Anchors address rendered text, not Markdown source.** Anchors come from a browser
selection, so inline markup is already gone from `anchor.exact`. Matching it literally
against the `.md` file fails wherever a quote crosses emphasis, code, or a link.

**A file outside a repository still works** — as a plain viewer with notes, no history.
`mdrev --notes` there still lists and resolves; only the range flags need git.

## Where notes live

`<repo>/.mdrev/annotations/<path-to-doc>.md.jsonl` — one JSON object per line,
append-only, committed with the repo. Reading them directly is fine when you need
something the CLI does not expose; **write through `--resolve`/`--wontfix`** rather than
rewriting the file, so status changes stay consistent with what the viewer shows.
